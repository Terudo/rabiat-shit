local LSM = LibStub("LibSharedMedia-3.0") 

-- ----- 
-- BACKGROUND 
-- ----- 

-- ----- 
--  BORDER 
-- ---- 

-- -----
--   FONT
-- -----
LSM:Register("font", "Numen", [[Interface\Addons\SharedMedia_MyMedia\font\Numen.ttf]]) 

-- -----
--   SOUND
-- -----

-- -----
--   STATUSBAR
-- -----
