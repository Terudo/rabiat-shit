local LSM = LibStub("LibSharedMedia-3.0") 

-- ----- 
-- BACKGROUND 
-- ----- 

-- ----- 
--  BORDER 
-- ---- 

-- -----
--   FONT
-- -----
LSM:Register("font", "Numen", [[Interface\Addons\SharedMedia_MyMedia\font\Numen.ttf]]) 

-- -----
--   SOUND
-- -----
LSM:Register("sound", "fojji Bell", [[Interface\Addons\SharedMedia_MyMedia\sound\Bell.ogg]])
LSM:Register("sound", "fojji Chime", [[Interface\Addons\SharedMedia_MyMedia\sound\Chime.ogg]])
LSM:Register("sound", "fojji Heart", [[Interface\Addons\SharedMedia_MyMedia\sound\Heart.ogg]])
LSM:Register("sound", "fojji IM", [[Interface\Addons\SharedMedia_MyMedia\sound\IM.ogg]])
LSM:Register("sound", "fojji Info", [[Interface\Addons\SharedMedia_MyMedia\sound\Info.ogg]])
LSM:Register("sound", "fojji Kachink", [[Interface\Addons\SharedMedia_MyMedia\sound\Kachink.ogg]])
LSM:Register("sound", "fojji Link", [[Interface\Addons\SharedMedia_MyMedia\sound\Link.ogg]])
LSM:Register("sound", "fojji Text1", [[Interface\Addons\SharedMedia_MyMedia\sound\Text1.ogg]])
LSM:Register("sound", "fojji Text2", [[Interface\Addons\SharedMedia_MyMedia\sound\Text2.ogg]])
LSM:Register("sound", "fojji Xylo", [[Interface\Addons\SharedMedia_MyMedia\sound\Xylo.ogg]])

-- -----
--   STATUSBAR
-- -----
LSM:Register("statusbar", "fojji Bar Texture", [[Interface\Addons\SharedMedia_MyMedia\statusbar\fojjiTexture.tga]])