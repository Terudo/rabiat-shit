local LSM = LibStub("LibSharedMedia-3.0") 

-- ----- 
-- BACKGROUND 
-- ----- 

-- ----- 
--  BORDER 
-- ---- 

-- -----
--   FONT
-- -----
LSM:Register("font", "Numen", [[Interface\Addons\SharedMedia_MyMedia\font\Numen.ttf]]) 

-- -----
--   SOUND
-- -----
LSM:Register("sound", "fojji Bell", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiBell.ogg]])
LSM:Register("sound", "fojji Chime", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiChime.ogg]])
LSM:Register("sound", "fojji Heart", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiHeart.ogg]])
LSM:Register("sound", "fojji IM", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiIM.ogg]])
LSM:Register("sound", "fojji Info", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiInfo.ogg]])
LSM:Register("sound", "fojji Kachink", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiKachkink.ogg]])
LSM:Register("sound", "fojji Link", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiLink.ogg]])
LSM:Register("sound", "fojji Text1", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiText1.ogg]])
LSM:Register("sound", "fojji Text2", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiText2.ogg]])
LSM:Register("sound", "fojji Xylo", [[Interface\Addons\SharedMedia_MyMedia\sound\fojjiXylo.ogg]])

-- -----
--   STATUSBAR
-- -----
LSM:Register("statusbar", "fojji Bar Texture", [[Interface\Addons\SharedMedia_MyMedia\statusbar\fojjiTexture.tga]])